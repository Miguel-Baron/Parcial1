"""Type definitions."""
