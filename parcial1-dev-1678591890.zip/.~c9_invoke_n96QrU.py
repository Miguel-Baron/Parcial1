"""
Your module description
"""
import boto3
import requests
import datetime
import csv
from bs4 import BeautifulSoup

def f(event, context):
    url = 'https://casas.mitula.com.co/searchRE/nivel3-Chapinero/nivel2-Bogotá/nivel1-Cundinamarca/q-Bogotá-Chapinero'
    bucket_name = 'landing-casas'
    now = datetime.datetime.now()
    date_string = now.strftime('%Y-%m-%d_%H-%M-%S')

    # Concatenar la cadena formateada con la extensión del archivo
    file_name = f'{date_string}.html'

    # Descargar el archivo
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36'
    }
    response = requests.get(url, headers=headers)
    content = response.content
    
    # Configurar el cliente de S3
    s3 = boto3.client('s3')
        
    # Subir el archivo a S3
    s3.put_object(Bucket=bucket_name, Key=file_name, Body=content)
    
    

def f2(event, context):
    s3 = boto3.client("s3")
    s3_bucket = 'landing-casas'

    # Realizar petición HTTP GET y almacenar la respuesta en una variable
    response = s3.list_objects_v2(Bucket=s3_bucket)

    # Ordenar la lista de objetos por la fecha de creación, de más nuevo a más antiguo
    objects = sorted(response['Contents'], key=lambda obj: obj['LastModified'], reverse=True)

    # Obtener el nombre del último archivo subido
    last_object = objects[0]
    body = last_object.get()['Key']
    #s3.download_file(s3_bucket, last_object)
    
    print(last_object)
    
    # Pasar el contenido HTML de la respuesta HTTP GET a un objeto BeautifulSoup
    """soup = BeautifulSoup(last_object.get()['Body'].read, 'html.parser')

    # Buscar los elementos HTML que contienen la información de cada casa
    casas = soup.select('.listing')

    # Crear archivo CSV
    now = datetime.datetime.now()
    fecha_descarga = now.strftime('%Y-%m-%d_%H-%M-%S')
    
    with open(f'casas_{fecha_descarga}.csv'.format(fecha_descarga), mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['FechaDescarga', 'Barrio', 'Valor', 'NumHabitaciones', 'NumBanos', 'mts2'])

    # Escribir información de cada casa en el archivo CSV
    for casa in casas:
        # Extraer la información deseada de cada elemento HTML encontrado
        titulo = casa.select_one('.title a').text.strip()
        precio = casa.select_one('.price').text.strip()
        descripcion = casa.select_one('.summary').text.strip()
        ubicacion = casa.select_one('.place').text.strip()

        # Extraer información adicional de la descripción de la casa
        num_habitaciones = None
        num_banos = None
        mts2 = None
        for detalle in descripcion.split('\n'):
            if 'habitacion' in detalle.lower():
                num_habitaciones = detalle.strip()
            elif 'baño' in detalle.lower():
                num_banos = detalle.strip()
            elif 'm²' in detalle:
                mts2 = detalle.strip()

        # Escribir información de cada casa en el archivo CSV
        writer.writerow([fecha_descarga, ubicacion, precio, num_habitaciones, num_banos, mts2])
    print(file)"""